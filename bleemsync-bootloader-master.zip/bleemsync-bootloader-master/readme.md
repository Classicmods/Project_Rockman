# BleemSync Bootloader

**This is closed source! Do not share!** This is to prevent people from fucking up the scripts and then eventually their consoles.

This uses Cyanic's bootstrapper

**PLEASE NOTE** Before you try to run the script. Make sure you have the dumped keys and pass from the psc into the root of this directory (`.gpupg`) and make sure you have execute permissions on `./gpg`

## To Build Payload (installing RNDIS/Telnet/FTP/SSH/USBHOST):

```bash
./build.sh payload 5 0
```

## Flags

The Bootloader uses the following flags:
- __UPDATE_TELNET__ : Updates the RNDIS/FTP/Telnet Hack
- __UPDATE_SSH__ : Installs and Updates SSH
- __UPDATE_USBHOST__ : Updates the USBHost Service that changes to HOST mode
- __BACKUP_MAIN__ : Backs up main partition set
- __BACKUP_KERNEL__ : Backs up kernel partition only
- __BACKUP_RECOVERY__ : Backs up the recovery partition set
- __RESTORE_MAIN__ : Restores main partiton set. _WARNING: ALL DATA WILL BE LOST_
- __RESTORE_KERNEL__ : Restores kernel partition
- __RESTORE_RECOVERY__ : Restores the recovery partition set
- __UNINSTALL__ : Uninstalls all hacks completely.
 
