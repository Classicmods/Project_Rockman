#!/bin/bash
#
#  Copyright 2019 ModMyClassic (https://modmyclassic.com/license)
#  
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
INTERMEDIATE_FILE=payload.tar.gz
GPG_HOME=".gnupg"

ID_LIST=(
    a4309d6c-3f9a-49b5-a049-080648213f06
    7c42a621-19a7-4f0a-86f7-d392810cf2fb
    e595d9f3-ceee-478c-93be-a6b0a09e26c1
    e7735188-50c9-432c-b812-1b6f86bdbd80
    59e52e68-3dec-4dfc-9f65-b19e1870f842
    d8781dae-c45c-4fc1-b961-e03eedebbffb
    35e2f31e-28a5-4ed1-ad5a-519b6accb029
    8c3bec2d-b553-4377-8cd8-303fdfa96c5b
    6eab3455-d7a9-4cfd-8e0c-f41d3e61b151
    691843bb-62d6-4423-a105-19c06af91a8c
    028c18a9-ec4b-4632-b2cf-d4e20f252e8f
    0c9bff18-9d52-4f10-ba72-6fa79496da2a
    f854cc9b-6cfc-4524-90a2-a2b35bbc3e24
    9d55025c-ceab-423a-be00-5a207888efd3
    b5becde4-e08f-48aa-b932-9972d89d6cae
    beca7fd8-d871-4870-b6fc-8c749058b27b
)

RECIPIENT_LIST=(
    "sgmodiag1@sgmodiag1.sony.com"
    "sgmodiag2@sgmodiag2.sony.com"
    "sgmodiag3@sgmodiag3.sony.com"
    "sgmodiag4@sgmodiag4.sony.com"
    "siecs1@siecs1.sony.com"
    "siecs2@siecs2.sony.com"
    "siecs3@siecs3.sony.com"
    "siecs4@siecs4.sony.com"
    "sieupdate1@sieupdate1.sony.com"
    "sieupdate2@sieupdate2.sony.com"
    "sieupdate3@sieupdate3.sony.com"
    "sieupdate4@sieupdate4.sony.com"
    "sieupdate5@sieupdate5.sony.com"
    "sieupdate6@sieupdate6.sony.com"
    "sieupdate7@sieupdate7.sony.com"
    "sieupdate8@sieupdate8.sony.com"
)

ID_SPLIT_INDEX=8
DIAG_FILENAME=LDIAG.BIN
DIAG_FLAG_FILENAME=diag
UPDATE_FILENAME=LUPDATA.BIN
APP_FILENAME=LAPPS.BIN

if [ "$#" -lt 2 ]; then
    echo "Usage: $0 folder_name id_index [is_app]"
    echo "  folder_name the name of the folder you want to pack"
    echo "  id_index    the key index to use (0-$(($ID_SPLIT_INDEX - 1)) for diag, ${ID_SPLIT_INDEX}-$((${#ID_LIST[@]} - 1)) for update)"
    echo "  is_app      write 1 if you want to use app filename instead"
    exit
fi

# Index check
if [ "$2" -ge ${#ID_LIST[@]} -o "$2" -lt 0 ]; then
    echo "Invalid key index"
    exit
fi

ID=${ID_LIST[$2]}
RECIPIENT=${RECIPIENT_LIST[$2]}
if [ -n "$3" -a "$3" -eq 1 ] &> /dev/null; then
    FILENAME=${APP_FILENAME}
else
    if [ "$2" -ge ${ID_SPLIT_INDEX} ]; then
        FILENAME=${UPDATE_FILENAME}
    else
        FILENAME=${DIAG_FILENAME}
    fi
fi

rm -f payload/bleemsync_loader.ver
GIT_COMMIT=$(echo "`git rev-parse --short HEAD``git diff-index --quiet HEAD -- || echo '-dirty'`")

    printf "%s\n" \
    "---" \
    "BleemSync Bootloader" \
    "Creator: ModMyClassic" \
    "Git Version: $GIT_COMMIT" \
    "Built by: $USER" \
    "Built on: $(date)" \
    "---" > payload_part1/bleemsync_loader.ver

    printf "%s\n" \
    "---" \
    "BleemSync Bootloader" \
    "Creator: ModMyClassic" \
    "Git Version: $GIT_COMMIT" \
    "Built by: $USER" \
    "Built on: $(date)" \
    "---" > payload_part2/bleemsync_loader.ver

rm -rf "out/${ID}"
mkdir -p "out/${ID}"
rm -f "out/${INTERMEDIATE_FILE}"
echo "Compressing..."
tar -C "$(dirname $1)" -zcvf "${INTERMEDIATE_FILE}" "$(basename $1)"
mv -f "${INTERMEDIATE_FILE}" "out/"
echo "Encrypting and signing..."
if ./gpg --no-tty --homedir "${GPG_HOME}" --yes --encrypt --symmetric --passphrase-file "${GPG_HOME}/pass" \
    --sign --recipient "${RECIPIENT}" --out "out/${ID}/${FILENAME}" "out/${INTERMEDIATE_FILE}"; then
	ok=1
else
	ok=0
fi

if [  "$2" -lt ${ID_SPLIT_INDEX} ]; then
    touch "out/${ID}/${DIAG_FLAG_FILENAME}"
fi

if [ "$ok" = "1" ]; then
	echo "[OK] Built payload successfully!"
	exit 0
else
	echo "[FAIL] Failed to build payload"
	exit 1
fi
